<?php
/**
 * Plugin Name: Zycus Landing Page
 * Plugin URI:  https://www.zycus.com/
 * Description: Custom plugin for the Zycus B2B procurement landing page. Provides the demo-request form shortcode, custom leads table, AJAX submission with validation, admin + user email notifications, admin lead viewer with CSV export, and GA4 event tracking.
 * Version:     1.0.0
 * Author:      Zycus
 * License:     GPL-2.0+
 * Text Domain: zycus-landing
 * Requires PHP: 7.4
 * Requires at least: 6.0
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'ZYCUS_LANDING_VERSION', '1.0.0' );
define( 'ZYCUS_LANDING_PATH', plugin_dir_path( __FILE__ ) );
define( 'ZYCUS_LANDING_URL', plugin_dir_url( __FILE__ ) );
define( 'ZYCUS_LANDING_TABLE', 'zycus_leads' );

require_once ZYCUS_LANDING_PATH . 'includes/class-zycus-db.php';
require_once ZYCUS_LANDING_PATH . 'includes/class-zycus-form-handler.php';
require_once ZYCUS_LANDING_PATH . 'includes/class-zycus-emails.php';
require_once ZYCUS_LANDING_PATH . 'includes/class-zycus-admin.php';
require_once ZYCUS_LANDING_PATH . 'includes/class-zycus-shortcode.php';
require_once ZYCUS_LANDING_PATH . 'includes/class-zycus-analytics.php';

register_activation_hook( __FILE__, array( 'Zycus_DB', 'install' ) );

add_action( 'plugins_loaded', function () {
    Zycus_Form_Handler::init();
    Zycus_Admin::init();
    Zycus_Shortcode::init();
    Zycus_Analytics::init();
} );

add_action( 'wp_enqueue_scripts', function () {
    wp_enqueue_style(
        'zycus-inter-font',
        'https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap',
        array(),
        null
    );

    wp_enqueue_style(
        'zycus-landing',
        ZYCUS_LANDING_URL . 'assets/css/zycus-landing.css',
        array( 'zycus-inter-font' ),
        ZYCUS_LANDING_VERSION
    );

    wp_enqueue_script(
        'zycus-landing',
        ZYCUS_LANDING_URL . 'assets/js/zycus-landing.js',
        array(),
        ZYCUS_LANDING_VERSION,
        true
    );

    wp_localize_script( 'zycus-landing', 'ZycusLanding', array(
        'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
        'nonce'     => wp_create_nonce( 'zycus_demo_submit' ),
        'gaId'      => get_option( 'zycus_ga4_id', '' ),
        'countries' => Zycus_Shortcode::countries(),
        'titles'    => Zycus_Shortcode::job_titles(),
    ) );
} );
